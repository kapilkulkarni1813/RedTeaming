﻿namespace Seatbelt.Commands
{
    public interface CommandDTOBase
    {
    }
}